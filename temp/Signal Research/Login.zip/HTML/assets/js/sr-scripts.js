// show password
function showPassword() {
    $("#togglePassword").on("click", function() {
        $(this).toggleClass("sr-eye-close");
        var inputType = $(this).parent(".password").find("input").attr("type");
        if (inputType == "password") {
            $(this).parent(".password").find("input").attr("type", "text");
        }
        else {
            $(this).parent(".password").find("input").attr("type", "password");
        }
    });
}

// Initiate Scripts
$(document).ready(function(){
    showPassword();
});