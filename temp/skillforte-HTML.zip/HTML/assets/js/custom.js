/* CSS Browser */
function css_browser_selector(u) {
    var ua = u.toLowerCase(), is = function (t) {
            return ua.indexOf(t) > -1
        }, g = 'gecko', w = 'webkit', s = 'safari', o = 'opera', m = 'mobile', h = document.documentElement,
        b = [(!(/opera|webtv/i.test(ua)) && /msie\s(\d)/.test(ua)) ? ('ie ie' + RegExp.$1) : is('firefox/2') ? g + ' ff2' : is('firefox/3.5') ? g + ' ff3 ff3_5' : is('firefox/3.6') ? g + ' ff3 ff3_6' : is('firefox/3') ? g + ' ff3' : is('gecko/') ? g : is('opera') ? o + (/version\/(\d+)/.test(ua) ? ' ' + o + RegExp.$1 : (/opera(\s|\/)(\d+)/.test(ua) ? ' ' + o + RegExp.$2 : '')) : is('konqueror') ? 'konqueror' : is('blackberry') ? m + ' blackberry' : is('android') ? m + ' android' : is('chrome') ? w + ' chrome' : is('iron') ? w + ' iron' : is('applewebkit/') ? w + ' ' + s + (/version\/(\d+)/.test(ua) ? ' ' + s + RegExp.$1 : '') : is('mozilla/') ? g : '', is('j2me') ? m + ' j2me' : is('iphone') ? m + ' iphone' : is('ipod') ? m + ' ipod' : is('ipad') ? m + ' ipad' : is('mac') ? 'mac' : is('darwin') ? 'mac' : is('webtv') ? 'webtv' : is('win') ? 'win' + (is('windows nt 6.0') ? ' vista' : '') : is('freebsd') ? 'freebsd' : (is('x11') || is('linux')) ? 'linux' : '', 'js'];
    c = b.join(' ');
    h.className += ' ' + c;
    return c;
};css_browser_selector(navigator.userAgent);
/* CSS Browser */

$(window).on("load",function(){	

	var _hero_home_img_H = $(".hero-home-img img").height();	
	$(".hero-home").css("height", _hero_home_img_H);
	$(".hero-home").css("min-height", _hero_home_img_H);

});

$(window).on("resize", function(){
	var _hero_home_img_H = $(".hero-home-img img").height();	
	$(".hero-home").css("height", _hero_home_img_H);
	$(".hero-home").css("min-height", _hero_home_img_H);
});

$(document).ready(function(){

	$('.hamburger').click (function(){
		$(this).toggleClass('open');
		$(".nav-sm").slideToggle();
		$("body").toggleClass("overflow-hidden");
	});

	/*------------------------------*/
	/*	 Scroll Header Bg
	/*------------------------------*/
	$(window).on("scroll", function() { 
		if ($("header").offset().top > 100) {
			 $("header").addClass("sticky");
		} else {
			 $("header").removeClass("sticky");
		}
	});
	
	// Owl Carousel
	var owl = $(".owl-carousel");
	owl.owlCarousel({
	  items: 4,
	  margin: 20,
	  loop: false,	  
	  //nav: true
	  nav: false,
	  responsive: {
        0:{
          items: 1
        },
        767:{
          items: 2
        },
        991:{
          items: 3
        },
		1500:{
			items: 4,
			stagePadding: 200
		}
    }
	});
  
});